from math import log

import StringDouble
import ExtractGraph


class BeamSearch:
    graph = []

    def __init__(self, input_graph):
        self.graph = input_graph
        return

    def beamSearchV1(self, pre_words, beamK, maxToken):
        # Basic Search using ExtractGraph
        graph1 = self.graph.graph
        res = list()
        sequence = [[pre_words, 0]]
        loop = 0
        # Create a list beginning with parameter pre_words;

        # Outer loop ends with maxToken
        while loop < maxToken:
            children = list()
            # get each structure in
            for i in range(len(sequence)):
                seq, prob = sequence[i]
                # For each word, find the node and probability in dictionary, and add them together, calculate the
                # probability with log prior. After all, add the child to temp list, children.
                for key in graph1[seq.split()[-1]].keys():
                    child = [seq + ' ' + key, prob + log(graph1[seq.split()[-1]][key])]
                    # Add all results that ended with '</s>' before the loops reach maxToken and the last three results.
                    if key == '</s>':
                        res.append(child)
                    else:
                        children.append(child)
            # Sort the result of each level, get the top of beamK results.
            st = sorted(children, key=lambda x: x[1], reverse=True)
            sequence = st[:beamK]
            loop += 1
        # Find the best result, transfer them to StringDouble.py.
        res.extend(sequence)
        temp = sorted(res, key=lambda x: x[1], reverse=True)
        temp = temp[0]
        sentence = temp[0]
        probability = temp[1]
        return StringDouble.StringDouble(sentence, probability)

    def beamSearchV2(self, pre_words, beamK, param_lambda, maxToken):
        # Beam search with sentence length normalization.
        graph1 = self.graph.graph
        res = list()
        sequence = [[pre_words, 0]]
        loop = 0

        # The calculation is similar with V1. Only difference is adding the probability between the pre_word and
        # current word.
        while loop < maxToken:
            children = list()
            for i in range(len(sequence)):
                seq, prob = sequence[i]
                length = len(seq.split())
                for key in graph1[seq.split()[-1]].keys():
                    # Since we divide the parameter with former length, we need to multiply the former length
                    # in order to get the original value.
                    child = [seq + ' ' + key, (prob * (length**param_lambda) + log(graph1[seq.split()[-1]][key]))
                             / (length + 1) ** param_lambda]
                    if key == '</s>':
                        res.append(child)
                    else:
                        children.append(child)
            st = sorted(children, key=lambda x: x[1], reverse=True)
            sequence = st[:beamK]
            loop += 1
        res.extend(sequence)
        temp = sorted(res, key=lambda x: x[1], reverse=True)
        temp = temp[0]
        sentence = temp[0]
        probability = temp[1]
        return StringDouble.StringDouble(sentence, probability)





