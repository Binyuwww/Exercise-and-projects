class StringDouble:

    string = ""

    score = 0.0

    def __init__(self, a, b):
        self.string = a
        self.score = b

