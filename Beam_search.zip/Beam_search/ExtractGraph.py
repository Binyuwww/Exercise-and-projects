class ExtractGraph:
    # key is head word; value stores next word and corresponding probability.
    graph = {}

    sentences_add = "data\\assign1_sentences.txt"
    sentences_add1 = "data\\test.txt"

    def __init__(self):
        # Extract the directed weighted graph, and save to {head_word, {tail_word, probability}}
        file = open(self.sentences_add)
        lr = {}
        for line in file:
            temp = line.split()
            for i in range(len(temp) - 1):
                # Add the count if the structure has already saved in the dict;
                if lr.__contains__(temp[i]) and lr[temp[i]].__contains__(temp[i + 1]):
                    lr.setdefault(temp[i], {})[temp[i + 1]] = lr[temp[i]][temp[i + 1]] + 1
                # Add new structure if there is no such ones in the dict;
                else:
                    lr.setdefault(temp[i], {})[temp[i + 1]] = 1
        for i in lr.keys():
            sum1 = 0
            # sum is the total times of word appeared behind the tail word
            for j in lr[i].keys():
                sum1 += lr[i][j]
            # change the frequency into probability after each tail_word
            for k in lr[i].keys():
                lr[i][k] /= sum1

        lr['</s>'] = {}
        self.graph = lr
        return

    def getProb(self, head_word, tail_word):
        if not self.graph[head_word].__contains__(tail_word):
            return 0
        else:
            return self.graph[head_word][tail_word]
